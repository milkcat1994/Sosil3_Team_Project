﻿namespace Project_Client
{
    partial class Create_Project
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel_Project_Name = new System.Windows.Forms.Panel();
            this.label_Project_name = new System.Windows.Forms.Label();
            this.textBox_Project_Name = new System.Windows.Forms.TextBox();
            this.panel_Project_Start_Date = new System.Windows.Forms.Panel();
            this.label_Project_Start_Date = new System.Windows.Forms.Label();
            this.textBox_Project_Start_Date = new System.Windows.Forms.TextBox();
            this.panel_Project_End_Date = new System.Windows.Forms.Panel();
            this.label_Project_End_Date = new System.Windows.Forms.Label();
            this.textBox_Project_End_Date = new System.Windows.Forms.TextBox();
            this.button_Create_Project = new System.Windows.Forms.Button();
            this.panel_Project_Name.SuspendLayout();
            this.panel_Project_Start_Date.SuspendLayout();
            this.panel_Project_End_Date.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel_Project_Name
            // 
            this.panel_Project_Name.Controls.Add(this.label_Project_name);
            this.panel_Project_Name.Controls.Add(this.textBox_Project_Name);
            this.panel_Project_Name.Location = new System.Drawing.Point(12, 12);
            this.panel_Project_Name.Name = "panel_Project_Name";
            this.panel_Project_Name.Size = new System.Drawing.Size(294, 25);
            this.panel_Project_Name.TabIndex = 1;
            // 
            // label_Project_name
            // 
            this.label_Project_name.AutoSize = true;
            this.label_Project_name.Dock = System.Windows.Forms.DockStyle.Left;
            this.label_Project_name.Location = new System.Drawing.Point(0, 0);
            this.label_Project_name.Name = "label_Project_name";
            this.label_Project_name.Size = new System.Drawing.Size(88, 12);
            this.label_Project_name.TabIndex = 1;
            this.label_Project_name.Text = "Project_Name:";
            // 
            // textBox_Project_Name
            // 
            this.textBox_Project_Name.Dock = System.Windows.Forms.DockStyle.Right;
            this.textBox_Project_Name.Location = new System.Drawing.Point(110, 0);
            this.textBox_Project_Name.Name = "textBox_Project_Name";
            this.textBox_Project_Name.Size = new System.Drawing.Size(184, 21);
            this.textBox_Project_Name.TabIndex = 0;
            // 
            // panel_Project_Start_Date
            // 
            this.panel_Project_Start_Date.Controls.Add(this.label_Project_Start_Date);
            this.panel_Project_Start_Date.Controls.Add(this.textBox_Project_Start_Date);
            this.panel_Project_Start_Date.Location = new System.Drawing.Point(12, 43);
            this.panel_Project_Start_Date.Name = "panel_Project_Start_Date";
            this.panel_Project_Start_Date.Size = new System.Drawing.Size(294, 25);
            this.panel_Project_Start_Date.TabIndex = 2;
            // 
            // label_Project_Start_Date
            // 
            this.label_Project_Start_Date.AutoSize = true;
            this.label_Project_Start_Date.Dock = System.Windows.Forms.DockStyle.Left;
            this.label_Project_Start_Date.Location = new System.Drawing.Point(0, 0);
            this.label_Project_Start_Date.Name = "label_Project_Start_Date";
            this.label_Project_Start_Date.Size = new System.Drawing.Size(106, 12);
            this.label_Project_Start_Date.TabIndex = 1;
            this.label_Project_Start_Date.Text = "Project_Start_Date";
            // 
            // textBox_Project_Start_Date
            // 
            this.textBox_Project_Start_Date.Dock = System.Windows.Forms.DockStyle.Right;
            this.textBox_Project_Start_Date.Location = new System.Drawing.Point(110, 0);
            this.textBox_Project_Start_Date.Name = "textBox_Project_Start_Date";
            this.textBox_Project_Start_Date.Size = new System.Drawing.Size(184, 21);
            this.textBox_Project_Start_Date.TabIndex = 0;
            // 
            // panel_Project_End_Date
            // 
            this.panel_Project_End_Date.Controls.Add(this.label_Project_End_Date);
            this.panel_Project_End_Date.Controls.Add(this.textBox_Project_End_Date);
            this.panel_Project_End_Date.Location = new System.Drawing.Point(12, 74);
            this.panel_Project_End_Date.Name = "panel_Project_End_Date";
            this.panel_Project_End_Date.Size = new System.Drawing.Size(294, 25);
            this.panel_Project_End_Date.TabIndex = 3;
            // 
            // label_Project_End_Date
            // 
            this.label_Project_End_Date.AutoSize = true;
            this.label_Project_End_Date.Dock = System.Windows.Forms.DockStyle.Left;
            this.label_Project_End_Date.Location = new System.Drawing.Point(0, 0);
            this.label_Project_End_Date.Name = "label_Project_End_Date";
            this.label_Project_End_Date.Size = new System.Drawing.Size(103, 12);
            this.label_Project_End_Date.TabIndex = 1;
            this.label_Project_End_Date.Text = "Project_End_Date";
            // 
            // textBox_Project_End_Date
            // 
            this.textBox_Project_End_Date.Dock = System.Windows.Forms.DockStyle.Right;
            this.textBox_Project_End_Date.Location = new System.Drawing.Point(110, 0);
            this.textBox_Project_End_Date.Name = "textBox_Project_End_Date";
            this.textBox_Project_End_Date.Size = new System.Drawing.Size(184, 21);
            this.textBox_Project_End_Date.TabIndex = 0;
            // 
            // button_Create_Project
            // 
            this.button_Create_Project.Location = new System.Drawing.Point(314, 27);
            this.button_Create_Project.Name = "button_Create_Project";
            this.button_Create_Project.Size = new System.Drawing.Size(75, 51);
            this.button_Create_Project.TabIndex = 4;
            this.button_Create_Project.Text = "Create Project";
            this.button_Create_Project.UseVisualStyleBackColor = true;
            this.button_Create_Project.Click += new System.EventHandler(this.button_Create_Project_Click);
            // 
            // Create_Project
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(401, 114);
            this.Controls.Add(this.button_Create_Project);
            this.Controls.Add(this.panel_Project_End_Date);
            this.Controls.Add(this.panel_Project_Start_Date);
            this.Controls.Add(this.panel_Project_Name);
            this.Name = "Create_Project";
            this.Text = "Create_Project";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Create_Project_FormClosed);
            this.panel_Project_Name.ResumeLayout(false);
            this.panel_Project_Name.PerformLayout();
            this.panel_Project_Start_Date.ResumeLayout(false);
            this.panel_Project_Start_Date.PerformLayout();
            this.panel_Project_End_Date.ResumeLayout(false);
            this.panel_Project_End_Date.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel_Project_Name;
        private System.Windows.Forms.Label label_Project_name;
        private System.Windows.Forms.TextBox textBox_Project_Name;
        private System.Windows.Forms.Panel panel_Project_Start_Date;
        private System.Windows.Forms.Label label_Project_Start_Date;
        private System.Windows.Forms.TextBox textBox_Project_Start_Date;
        private System.Windows.Forms.Panel panel_Project_End_Date;
        private System.Windows.Forms.Label label_Project_End_Date;
        private System.Windows.Forms.TextBox textBox_Project_End_Date;
        private System.Windows.Forms.Button button_Create_Project;
    }
}